from fastapi import APIRouter, HTTPException, Header
from models import ChatModel
from database import get_supabase
import httpx, jwt, os
from dotenv import load_dotenv

load_dotenv()
router = APIRouter()

SYSTEM_PROMPT = """
You are MediMind, a compassionate and knowledgeable AI medical assistant
built for human welfare, especially for people in Pakistan who may not
have easy access to doctors.

Your responsibilities:
- Listen carefully to the patient's symptoms
- Ask simple follow-up questions if needed
- Suggest possible conditions in simple, easy language
- Give basic home remedy advice for minor issues
- Always clearly tell patients when they MUST see a real doctor immediately
- Support both English and Urdu languages naturally
- Be warm, calm, and empathetic in every response
- Use simple bullet points for clarity
- Keep responses concise and easy to understand

Strict rules you must always follow:
- NEVER claim to replace a real doctor
- NEVER prescribe specific medication doses
- ALWAYS recommend emergency services for chest pain,
  difficulty breathing, stroke symptoms, or severe bleeding
- NEVER give advice that could cause harm
- Always end your response with a clear recommendation:
  whether to rest at home, visit a clinic, or go to emergency

Remember: You are serving people who may be vulnerable and scared.
Be their trusted, caring health companion.
"""


def get_user_from_token(token: str):
    try:
        return jwt.decode(
            token,
            os.getenv("JWT_SECRET"),
            algorithms=["HS256"]
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired, please login again")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")


# ── SEND MESSAGE TO GROQ AI ──
@router.post("/send")
async def send_message(data: ChatModel, authorization: str = Header(...)):
    token = authorization.replace("Bearer ", "")
    user = get_user_from_token(token)

    supabase = get_supabase()

    # Get user health profile for personalized advice
    profile = supabase.table("health_profiles")\
        .select("*")\
        .eq("user_id", user["id"])\
        .execute()

    # Build personalized patient context if profile exists
    patient_context = ""
    if profile.data:
        p = profile.data[0]
        patient_context = f"""
Patient profile:
- Age: {p.get('age', 'not provided')}
- Gender: {p.get('gender', 'not provided')}
- Blood group: {p.get('blood_group', 'not provided')}
- Weight: {p.get('weight', 'not provided')} kg
- Height: {p.get('height', 'not provided')} cm
- Existing conditions: {p.get('existing_conditions', 'none')}
- Allergies: {p.get('allergies', 'none')}

Please consider this profile when giving health advice.
"""

    # Call Groq API
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {os.getenv('GROQ_API_KEY')}",
                "Content-Type": "application/json"
            },
            json={
                "model": "llama3-8b-8192",
                "messages": [
                    {
                        "role": "system",
                        "content": SYSTEM_PROMPT
                    },
                    {
                        "role": "user",
                        "content": f"{patient_context}\nPatient says: {data.message}"
                    }
                ],
                "max_tokens": 1024,
                "temperature": 0.7
            }
        )

    if response.status_code != 200:
        raise HTTPException(
            status_code=500,
            detail="AI service failed. Please try again."
        )

    ai_reply = response.json()["choices"][0]["message"]["content"]

    # Auto-detect severity from AI response keywords
    severity = "low"
    high_keywords = [
        "emergency", "immediately", "hospital", "ambulance",
        "critical", "urgent", "call 115", "life-threatening"
    ]
    medium_keywords = [
        "doctor", "consult", "clinic", "appointment",
        "soon", "within 24", "visit"
    ]

    if any(word in ai_reply.lower() for word in high_keywords):
        severity = "high"
    elif any(word in ai_reply.lower() for word in medium_keywords):
        severity = "medium"

    # Save consultation to Supabase
    supabase.table("consultations").insert({
        "user_id": user["id"],
        "symptoms": data.message,
        "ai_response": ai_reply,
        "severity": severity
    }).execute()

    return {
        "reply": ai_reply,
        "severity": severity
    }


# ── GET CONSULTATION HISTORY ──
@router.get("/history")
def get_history(authorization: str = Header(...)):
    token = authorization.replace("Bearer ", "")
    user = get_user_from_token(token)

    supabase = get_supabase()
    result = supabase.table("consultations")\
        .select("*")\
        .eq("user_id", user["id"])\
        .order("created_at", desc=True)\
        .execute()

    return {"consultations": result.data}


# ── DELETE A SINGLE CONSULTATION ──
@router.delete("/history/{consultation_id}")
def delete_consultation(consultation_id: int, authorization: str = Header(...)):
    token = authorization.replace("Bearer ", "")
    user = get_user_from_token(token)

    supabase = get_supabase()
    supabase.table("consultations")\
        .delete()\
        .eq("id", consultation_id)\
        .eq("user_id", user["id"])\
        .execute()

    return {"message": "Consultation deleted successfully"}
